<!DOCTYPE html> <html lang="es-ES"> <head>
    <meta charset="utf-8"> </head> <body> <h2>Mensaje desde alumno.mobi</h2> <div>
    Tiene un nuevo mensaje:<br />
    {!! $text !!} </div> </body> </html>
