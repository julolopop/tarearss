<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tarea;

class SitesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Tarea::all();
    }

    public function store(Request $request)
    {
        $tarea = Tarea::create($request->all());

       return response()->json($tarea, 201);
    }

    public function show(Tarea $tarea)
    {
        return $tarea;
    }

    public function update(Request $request, Tarea $tarea)
    {
        $tarea->update($request->all());

        return response()->json($tarea, 200);
    }

    public function delete(Tarea $tarea)
    {
        $tarea->delete();

        return response()->json(null, 204);
    }

}

