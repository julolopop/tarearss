<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Validator;
use Exception;
use App\Tarea;

class EmailController extends Controller
{
	public function send(Request $request) {

		$email = $request->json()->all();
		$to = $email['to'];
		$subject = $email['subject'];
		$content =  Tarea::all();
		$data = array(
			'text' => $content,
		);
		//resources/views/emails/sendemail.blade.php
		try {
			Mail::send('emails.sendemail', $data, function ($message) use ($to, $subject) {
				$message->from($to);
				//$message->from('yourEmail@domain.com', 'mi Nombre');
				$message->to($to);
				$message->subject($subject);
	    });
		} catch (Exception $exception) {
				return response()->json(['status' => false, 'message' =>
$exception->getMessage()], 554);
		}
		return response()->json(['status' => true, 'to' => $to, 'subject' => $subject, 'content' =>
$content, 'message' => 'Your email has been sent successfully'], 250);
}
}
